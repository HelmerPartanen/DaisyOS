import 'package:flutter/material.dart';
import 'package:localsend_app/config/theme.dart';
import 'package:localsend_app/gen/strings.g.dart';
import 'package:localsend_app/model/state/send/web/web_download_state.dart';
import 'package:localsend_app/provider/network/server/server_provider.dart';
import 'package:pretty_qr_code/pretty_qr_code.dart';
import 'package:refena_flutter/refena_flutter.dart';
import 'package:routerino/routerino.dart';

class QrDialog extends StatelessWidget {
  final String data;
  final String? label;
  final bool listenIncomingWebDownloadRequests;
  final String? pin;

  const QrDialog({
    required this.data,
    this.label,
    this.listenIncomingWebDownloadRequests = false,
    this.pin,
  });

  @override
  Widget build(BuildContext context) {
    final WebDownloadState? webDownloadState;
    if (listenIncomingWebDownloadRequests) {
      webDownloadState = context.ref.watch(serverProvider.select((s) => s?.webDownloadState));
    } else {
      webDownloadState = null;
    }

    return AlertDialog(
      title: Text(t.dialogs.qr.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
              width: 200,
              height: 200,
              child: PrettyQrView.data(
                errorCorrectLevel: QrErrorCorrectLevel.Q,
                data: data,
                decoration: PrettyQrDecoration(
                  shape: PrettyQrSmoothSymbol(
                    roundFactor: 0,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(label ?? data, textAlign: TextAlign.center),
          if (listenIncomingWebDownloadRequests && webDownloadState != null)
            Builder(
              builder: (context) {
                final pending = webDownloadState?.sessions.values.fold<int>(0, (prev, curr) => prev + (curr.pending ? 1 : 0)) ?? 0;
                if (pending != 0) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      t.webSharePage.pendingRequests(n: pending),
                      style: TextStyle(color: Theme.of(context).colorScheme.warning),
                      textAlign: TextAlign.center,
                    ),
                  );
                } else {
                  return Container();
                }
              },
            ),
          if (pin != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.vpn_key),
                  const SizedBox(width: 5),
                  Text(pin!),
                ],
              ),
            ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => context.pop(),
          child: Text(t.general.close),
        ),
      ],
    );
  }
}
