import 'package:dart_mappable/dart_mappable.dart';
import 'package:localsend_app/model/state/send/sending_file.dart';
import 'package:localsend_app/model/state/server/receive_session_state.dart';
import 'package:localsend_isolates/model/device.dart';
import 'package:localsend_isolates/model/session_status.dart';

part 'send_session_state.mapper.dart';

@MappableClass()
class SendSessionState with SendSessionStateMappable implements SessionState {
  final String sessionId;
  final String? remoteSessionId; // v2
  final bool background;

  @override
  final SessionStatus status;

  final Device target;
  final Map<String, SendingFile> files; // file id as key

  /// Amount of files whose checksum has been calculated.
  /// The checksums are calculated before the request is sent to the receiver,
  /// so this is less than the file count while the session is being prepared.
  final int hashedFileCount;

  @override
  final int? startTime;

  @override
  final int? endTime;

  final List<SendingTask>? sendingTasks; // used to cancel tasks
  final String? errorMessage;

  const SendSessionState({
    required this.sessionId,
    required this.remoteSessionId,
    required this.background,
    required this.status,
    required this.target,
    required this.files,
    required this.hashedFileCount,
    required this.startTime,
    required this.endTime,
    required this.sendingTasks,
    required this.errorMessage,
  });

  /// Custom toString() to avoid printing the bytes.
  /// The default toString() does not respect the overridden toString() of
  /// SendingFile.
  @override
  String toString() {
    return 'SendSessionState(sessionId: $sessionId, remoteSessionId: $remoteSessionId, background: $background, status: $status, target: $target, files: $files, hashedFileCount: $hashedFileCount, startTime: $startTime, endTime: $endTime, sendingTasks: $sendingTasks, errorMessage: $errorMessage)';
  }
}

class SendingTask {
  final int taskId;

  SendingTask({
    required this.taskId,
  });
}
